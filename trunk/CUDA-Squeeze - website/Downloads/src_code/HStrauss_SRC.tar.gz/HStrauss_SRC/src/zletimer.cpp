/*
 *  Created on: Jun 13, 2013
 *  Author: Heinrich Strauss <heinrich@hstrauss.co.za>
 *  This software is licenced under the GPL v2.0 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt>
 */

#include "h/zletimer.h"

timespec zletimer::tstart;
timespec zletimer::tstop;
timespec zletimer::mtstart;
timespec zletimer::mtstop;

void zletimer::start() {
	//  using namespace zletimer;
	clock_gettime( CLOCK_REALTIME, &zletimer::tstart);
}

uint64_t zletimer::stop() {
	//  using namespace zletimer;
	clock_gettime( CLOCK_REALTIME, &zletimer::tstop);
	return (zletimer::tstop.tv_sec - zletimer::tstart.tv_sec)
			* (1000 * 1000 * 1000L)
			+ (zletimer::tstop.tv_nsec - zletimer::tstart.tv_nsec);
}

void zletimer::mstart() {
	//  using namespace zletimer;
	clock_gettime( CLOCK_MONOTONIC, &zletimer::mtstart);
}

uint64_t zletimer::mstop() {
	//  using namespace zletimer;
	clock_gettime( CLOCK_MONOTONIC, &zletimer::mtstop);
	return (zletimer::mtstop.tv_sec - zletimer::mtstart.tv_sec)
			* (1000 * 1000 * 1000L)
			+ (zletimer::mtstop.tv_nsec - zletimer::mtstart.tv_nsec);
}
