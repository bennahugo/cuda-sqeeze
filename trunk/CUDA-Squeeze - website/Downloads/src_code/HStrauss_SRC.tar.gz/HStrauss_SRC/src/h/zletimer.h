/*
 *  Created on: Jun 13, 2013
 *  Author: Heinrich Strauss <heinrich@hstrauss.co.za>
 *  This software is licenced under the GPL v2.0 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt>
 */

#ifndef ZLETIMER_H
#define ZLETIMER_H

#include <time.h>
#include "zledefs.h"

namespace zletimer {
extern timespec tstart, tstop, mtstart, mtstop;
void start();
uint64_t stop();
void mstart();
uint64_t mstop();
}
#endif // ZLETIMER_H
