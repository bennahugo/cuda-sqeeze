/*
 *  Created on: Jun 13, 2013
 *  Author: Heinrich Strauss <heinrich@hstrauss.co.za>
 *  This software is licenced under the GPL v2.0 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt>
 */

#ifndef ZLEDEFS_H
#define ZLEDEFS_H

#include <stdint.h>

//#define DEBUG
//#define DEBUG_ARGS
//#define DEBUG_SHOW_COMPRESSION_LOOP
//#define DEBUG_DUMP_TO_OUTPUT_FILE
//#define DEBUG_DUMP_FILE_NAME "original.dmp"
//#define DEBUG_HDF5READER
#define DEBUG_USE_RAW_FILE
//#define DEBUG_NO_CMP_WRITING
#define CONST_NUMBER_OF_RUNS 3
#define CONST_DEFAULT_BLOCK_SIZE_BYTES (1<<22) // no more than 16 for naive implementation
// CONST_ALG: 4 = RLE, 5 = ZLE (b0rk), 6 = ZLE (retry)
#define CONST_ALG 6
#define CONST_FACTOR_BYTE ((double)(1.0))
#define CONST_FACTOR_KILO ((double)(1000.0))
#define CONST_FACTOR_MEGA (((double)(1000.0))*1000)
#define CONST_FACTOR_GIGA (((double)(1000.0))*1000*1000)
#define CONST_FACTOR_TERA (((double)(1000.0))*1000*1000*1000)

#define CONST_FACTOR_ms ((double)(1000.0))
#define CONST_FACTOR_us (((double)(1000.0))*1000)
#define CONST_FACTOR_ns (((double)(1000.0))*1000*1000)

#define CONST_SIZE_C_FILE_HEAD 16

//#define CONST_DEFAULT_FILENAME "data/15mb.dump"
//#define CONST_RAW_FILENAME_IN "10mb.null.dump"
//#define CONST_RAW_FILENAME_IN "1kb.1_shl_22_bs.dump"
//#define CONST_RAW_FILENAME_IN "1kb.fbomb.dump"
#define CONST_RAW_FILENAME_COUT "compressed.out"
#define CONST_RAW_FILENAME_UOUT "decompressed.out"
//#define CONST_RAW_FILENAME_IN "data/15mb.dump"
//#define CONST_RAW_FILENAME_COUT "859mb.dump.cmp.out"
//#define CONST_RAW_FILENAME_UOUT "859mb.dump.unc.out"
//#define CONST_RAW_FILE_SIZE 10485760
//#define CONST_RAW_FILE_SIZE 1024
//#define CONST_RAW_FILE_SIZE 12845056
//#define CONST_RAW_FILE_SIZE 792723456
//#define CONST_RAW_FILE_SIZE 2288254976
#define CONST_NUM_THREADS 4

#define CONST_SPEED_LOWER_LIMIT 32.0d*1024

#define C_SIZE_LIMIT 252 // removed three repetitions to enable guard block at end of data == 0xFFFFFF or 0x000000
#define C_SIZE_RESERVED (255 - C_SIZE_LIMIT)
#define C_ZERO_MARKER 0
#define C_MARKER 255

#define C_IGNORE_LAST_ENCODING 2
#define C_IGNORE_LAST_DECODING 2


//#define float32_t float

// TO-DO: replace with stdint.h defs
//typedef unsigned char uchar_t;
typedef unsigned char byte;

//typedef unsigned char uint8_t;
//typedef unsigned short uint16_t;
//typedef unsigned int uint32_t;
//typedef unsigned long int uint64_t;
//typedef unsigned long long int uint128_t;

//typedef short float float16_t;
typedef float float32_t;
//typedef float float32_t;
//typedef double float64_t;
//typedef long double float80_t;
//typedef __float128 float128_t;

//typedef cfloat32_t
struct cfloat32_s {
	float32_t re;
	float32_t im;
};
typedef cfloat32_s cfloat32_t;

struct nybble_s
{
	unsigned int data : 4 ;
};
typedef nybble_s nybble_t;

#ifdef DEBUG
#define printdb1(x) fprintf(stderr,x);
#define printdb2(x,y) fprintf(stderr,x,y);
#else
#define printdb1(x) do {} while (false);
#define printdb2(x,y) do {} while (false);
//#define printdb1(x) for(;false;);
//#define printdb2(x,y) for (;false;);
#endif

#define MAX(a,b) \
		({ __typeof__ (a) _a = (a); \
		__typeof__ (b) _b = (b); \
		_a > _b ? _a : _b; })

#define MIN(a,b) \
		({ __typeof__ (a) _a = (a); \
		__typeof__ (b) _b = (b); \
		_a < _b ? _a : _b; })

#endif /* ZLEDEFS_H */
