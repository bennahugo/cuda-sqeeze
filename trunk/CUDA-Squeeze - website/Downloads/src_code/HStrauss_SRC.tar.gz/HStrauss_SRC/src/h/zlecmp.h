/*
 *  Created on: Jun 13, 2013
 *  Author: Heinrich Strauss <heinrich@hstrauss.co.za>
 *  This software is licenced under the GPL v2.0 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt>
 */

#ifndef ZLECMP_H
#define ZLECMP_H
#include <assert.h>
#include <string>
#include "zledefs.h"


class zlecmp {
public:
	static uint8_t zcompress  (const uint64_t p_block_index, const uint64_t p_blockSize, uint64_t *p_uncompressed_bytes, uint64_t* p_block_output_size_bytes, void* p_input, void* p_output);
	static uint8_t zdecompress(const uint64_t p_block_index, const uint64_t p_blockSize, const uint64_t p_output_blockSize, uint64_t* p_block_output_size_bytes, void* p_input, void* p_output);
	static uint8_t zcompress_mp  (const uint64_t p_block_index, const uint64_t p_blockSize, uint64_t *p_uncompressed_bytes, uint64_t* p_block_output_size_bytes, void* p_input, void* p_output);
	static uint8_t zdecompress_mp(const uint64_t p_block_index, const uint64_t p_blockSize, const uint64_t p_output_blockSize, uint64_t* p_block_output_size_bytes, void* p_input, void* p_output);

};


#endif // ZLECMP_H
